-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Sep 09, 2024 at 02:02 PM
-- Server version: 8.3.0
-- PHP Version: 8.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inventory`
--

-- --------------------------------------------------------

--
-- Table structure for table `costumer`
--

DROP TABLE IF EXISTS `costumer`;
CREATE TABLE IF NOT EXISTS `costumer` (
  `c_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(300) NOT NULL,
  `address` varchar(300) NOT NULL,
  `email` varchar(300) NOT NULL,
  PRIMARY KEY (`c_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `costumer`
--

INSERT INTO `costumer` (`c_id`, `name`, `address`, `email`) VALUES
(1, 'Anand', '123,borra_valley', 'Anand@gmail.com'),
(2, 'Aadhvita', '456,victorial_road', 'Aadhvita@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `delivery`
--

DROP TABLE IF EXISTS `delivery`;
CREATE TABLE IF NOT EXISTS `delivery` (
  `d_id` int NOT NULL AUTO_INCREMENT,
  `salesdate` date NOT NULL,
  `location` varchar(300) NOT NULL,
  `delivery_fee` int NOT NULL,
  `quantity` int NOT NULL,
  `Status` varchar(200) NOT NULL,
  PRIMARY KEY (`d_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `delivery`
--

INSERT INTO `delivery` (`d_id`, `salesdate`, `location`, `delivery_fee`, `quantity`, `Status`) VALUES
(1, '2024-06-06', '23,Anand_Nagar', 200, 4, 'Delivered'),
(2, '2024-07-10', '24,JC_Road', 500, 2, 'Pending'),
(3, '2024-05-15', '25,Willson_Garden', 600, 6, 'Delivered'),
(4, '2024-06-13', '26,Jaynagar', 750, 3, 'Delivered');

-- --------------------------------------------------------

--
-- Table structure for table `inventory_mang`
--

DROP TABLE IF EXISTS `inventory_mang`;
CREATE TABLE IF NOT EXISTS `inventory_mang` (
  `inventory_id` int NOT NULL AUTO_INCREMENT,
  `quantity_available` int NOT NULL,
  `max_stock` int NOT NULL,
  `quantity_sold` int NOT NULL,
  `product_name` varchar(100) DEFAULT NULL,
  `sales_date` varchar(100) DEFAULT NULL,
  `quantity_remaining` int DEFAULT NULL,
  `Price` decimal(8,2) DEFAULT NULL,
  PRIMARY KEY (`inventory_id`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `inventory_mang`
--

INSERT INTO `inventory_mang` (`inventory_id`, `quantity_available`, `max_stock`, `quantity_sold`, `product_name`, `sales_date`, `quantity_remaining`, `Price`) VALUES
(1, 200, 500, 150, 'Product A', '24-03-2024', 50, 15.00),
(2, 250, 500, 100, 'Product B', '24-06-24', 150, 20.00),
(3, 300, 500, 200, 'Product C', '24-07-05', 100, 10.00),
(4, 350, 500, 150, 'Product D', '24-04-21', 200, 25.00),
(22, 500, 600, 100, 'Product G', '2024-08-06', 400, 30.00),
(12, 400, 500, 200, 'Product E', '24-05-05', 200, 30.00);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE IF NOT EXISTS `orders` (
  `orderid` int NOT NULL AUTO_INCREMENT,
  `product_id` int NOT NULL,
  `manufacturer` varchar(300) NOT NULL,
  `price/item` double NOT NULL,
  `quantity` int NOT NULL,
  `product name` varchar(300) NOT NULL,
  `Total price` int NOT NULL,
  PRIMARY KEY (`orderid`),
  KEY `fk_product` (`product_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`orderid`, `product_id`, `manufacturer`, `price/item`, `quantity`, `product name`, `Total price`) VALUES
(1, 0, 'S.K.Productions', 10, 50, 'Product C', 500),
(2, 1, 'M.K.Productions', 15, 200, 'Product A', 3000),
(3, 2, 'S.K Production', 20, 250, 'Product B', 5000);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `product_id` int NOT NULL AUTO_INCREMENT,
  `p_name` varchar(300) NOT NULL,
  `quantity` int NOT NULL,
  `productions` varchar(300) NOT NULL,
  `category` varchar(300) NOT NULL,
  `price` decimal(50,0) NOT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `p_name`, `quantity`, `productions`, `category`, `price`) VALUES
(1, 'Product A', 200, 'M.K.Productions', 'stationary', 15),
(0, 'Product C', 300, 'S.K.Productions', 'dispensary', 10);

-- --------------------------------------------------------

--
-- Table structure for table `provider`
--

DROP TABLE IF EXISTS `provider`;
CREATE TABLE IF NOT EXISTS `provider` (
  `provider_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(300) NOT NULL,
  `address` varchar(300) NOT NULL,
  PRIMARY KEY (`provider_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `provider`
--

INSERT INTO `provider` (`provider_id`, `name`, `address`) VALUES
(1, 'M.K.Productions', 'Jayanagar'),
(2, 'S.K.Productions', 'Basavangudi');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `login_id` int NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`username`, `password`, `email`, `login_id`) VALUES
('admin', '1a1dc91c907325c69271ddf0c944bc', 'vasudharao799@gmail.com', 0),
('user', '5f4dcc3b5aa765d61d8327deb882cf', 'tyson@gmail.com', 0),
('username', '482c811da5d5b4bc6d497ffa98491e', 'style@gmail.com', 0),
('admin2', 'c24a542f884e144451f9063b79e799', 'rylie@gmail.com', 0);

-- --------------------------------------------------------

--
-- Table structure for table `warehouse`
--

DROP TABLE IF EXISTS `warehouse`;
CREATE TABLE IF NOT EXISTS `warehouse` (
  `warehouse_id` int NOT NULL AUTO_INCREMENT,
  `location` varchar(300) NOT NULL,
  `name` varchar(300) NOT NULL,
  PRIMARY KEY (`warehouse_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2457 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `warehouse`
--

INSERT INTO `warehouse` (`warehouse_id`, `location`, `name`) VALUES
(123, 'Aveenu_road', 'Brite_Logistics'),
(2456, 'Watson_mark Road', 'bin');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
