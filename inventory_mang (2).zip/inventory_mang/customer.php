<?php
// Database connection settings
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "inventory";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL query to fetch customer details
$sql = "SELECT c_id, name, address, email FROM costumer";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Details</title>
    <style>
        body {
            font-family: Courier new,cursive;
            margin: 20px;
            font-size: 1.7em;
            text-align: left;
            


            background-color: #f8f8f8;
            background: url('cust.jpg') no-repeat center center fixed;
            background-size: cover;
        }
        table {
            width: 100%;
            font-size: 1em;
            background-color: whitesmoke;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        h1{
            font-size: 2em;
            text-decoration-line: underline;
        }
        table, th, td {
            border: 1px solid #ddd;
            
        }
        
        th, td {
            padding: 12px;
            text-align: left;
            
        }
        th {
            background-color: lavender;
        }
    </style>
</head>
<body>
    <h1>CUSTOMER DETAILS</h1>
    <table>
        <thead>
            <tr>
                <th>Customer ID</th>
                <th>Name</th>
                <th>Address</th>
                <th>Email</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($result->num_rows > 0) {
                // Output data of each row
                while($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td>{$row['c_id']}</td>
                            <td>{$row['name']}</td>
                            <td>{$row['address']}</td>
                            <td>{$row['email']}</td>
                          </tr>";
                }
            } else {
                echo "<tr><td colspan='4'>No customers found</td></tr>";
            }
            ?>
        </tbody>
    </table>
</body>
</html>

<?php
$conn->close();
?>
