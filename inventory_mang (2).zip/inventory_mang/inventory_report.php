<?php
include 'connect_db.php';

// Fetch inventory data
$sql = "SELECT product_name, Price, max_stock, quantity_available, quantity_sold, quantity_remaining, sales_date FROM inventory_mang";
$result = $conn->query($sql);

// Prepare data for graphs
$data = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
}
$time_period = $_GET['time_period'] ?? '7_days';
$interval = 'INTERVAL 7 DAY'; // Default to last 7 days

switch ($time_period) {
    case '1_month':
        $interval = 'INTERVAL 1 MONTH';
        break;
    case '3_months':
        $interval = 'INTERVAL 3 MONTH';
        break;
    case '6_months':
        $interval = 'INTERVAL 6 MONTH';
        break;
}

$sql = "SELECT product_name, Price, max_stock, quantity_available, quantity_sold, quantity_remaining, sales_date 
        FROM inventory_mang 
        WHERE sales_date >= DATE_SUB(CURDATE(), $interval)";
$result = $conn->query($sql);
// Convert data to JSON format for JavaScript
$jsonData = json_encode($data);


// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory Report</title>
    <link rel="stylesheet" href="styles.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        /* Reset some default styles */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

/* Container styling */
.container {
    width: 100%;
    margin: 0 auto;
    padding: 20px;

    background-color: white;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    font-family: Courier new,cursive;
    background: url('ret.jpg') no-repeat center center fixed;
            background-size: cover;
}

/* Form container box styling */
.form-container {
    padding: 20px;
    margin-bottom: 30px;
    background-color: whitesmoke;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

/* Form styling */
form {
    margin-bottom: 30px;
}
.container h1{
font-size:3em;
color:black;
font-weight: bold;
text-decoration-line: underline;
}
form h1 {
    margin-bottom: 30px; /* Increase this value to add more space */
    font-size: 2em;
}
h2{
    color: black;
    text-decoration-line: underline;
}

form label {
    display: block;
    margin: 10px 0 5px;
    font-size: 24px;
    font-weight: bold;
}

form input[type="text"],
form input[type="number"],
form input[type="date"],
form input[type="submit"],
form button {
    width: 100%;
    padding: 10px;
    margin-bottom: 15px;
    border: 1px solid #ccc;
    border-radius: 4px;
    font-size: 16px;
}

form button {
    background-color: #4CAF50;
    color: white;
    border: none;
    cursor: pointer;
    transition: background-color 0.3s;
}

form button:hover {
    background-color: #45a049;
}

/* Table styling */
table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
    background-color: white;
    color: black;
}

table, th, td {
    border: 1px solid #ddd;
    background-color: whitesmoke;
    color: black;
}

th, td {
    padding: 12px;
    text-align: left;
}

th {
    background-color: lavender;
    font-weight: bold;
}

tr:nth-child(even) {
    background-color: #f9f9f9;
}

/* Responsive design */
@media (max-width: 600px) {
    .container {
        width: 100%;
        padding: 10px;
    }

    form input[type="text"],
    form input[type="number"],
    form input[type="date"],
    form input[type="submit"],
    form button {
        width: 100%;
    }

    table, th, td {
        font-size: 14px;
    }
}

/* Chart styling */
canvas {
    max-width: 80%;
    margin-top: 30px;
    font-size: 20px;
    margin-left: 130px;
    background-color: lavender ;
    color: white;
}
.filter-buttons {
            margin: 20px 0;
        }
        .filter-buttons button {
            padding: 10px 15px;
            width: 20%;
            margin-right: 5px;
            border: none;
            background-color: rebeccapurple;
            color: white;
            cursor: pointer;
        }
.filter-buttons button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    
    <div class="container">
        <h1>INVENTORY REPORTS</h1>

        <h2>EXISTING INVENTORY</h2>
        <table id="inventory-table">
            <thead>
                <tr>
                    <th>Product Name</th>
                    <th>Price</th>
                    <th>Max Stock</th>
                    <th>Quantity Available</th>
                    <th>Quantity Sold</th>
                    <th>Quantity Remaining</th>
                    <th>Sales Date</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if (!empty($data)) {
                    foreach ($data as $row) {
                        echo "<tr>
                                <td>{$row['product_name']}</td>
                                <td>{$row['Price']}</td>
                                <td>{$row['max_stock']}</td>
                                <td>{$row['quantity_available']}</td>
                                <td>{$row['quantity_sold']}</td>
                                <td>{$row['quantity_remaining']}</td>
                                <td>{$row['sales_date']}</td>
                              </tr>";
                    }
                } else {
                    echo "<tr><td colspan='7'>No items found</td></tr>";
                }
                ?>
            </tbody>
        </table>
        <!-- <form action="inventory_report.php" method="GET"> -->
    <!-- <label for="time_period">Filter by time period:</label> -->
    <!-- <div class="filter-buttons"> -->
        <!-- <button>Apply Filter</button> -->
<!-- </form> -->


        <h2>Inventory Sales Graph</h2>
        <canvas id="salesChart"></canvas>
    </div>

    <script>
        // Parse the JSON data from PHP
        var inventoryData = <?php echo $jsonData; ?>;

        // Prepare data for Chart.js
        var labels = inventoryData.map(item => item.product_name);
        var quantitySoldData = inventoryData.map(item => item.quantity_sold);

        // Create the chart
        var ctx = document.getElementById('salesChart').getContext('2d');
        var salesChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Quantity Sold',
                    data: quantitySoldData,
                    backgroundColor: 'rgba(75, 192, 192, 0.2)',
                    borderColor: 'rgba(75, 192, 192, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
</body>
</html>
