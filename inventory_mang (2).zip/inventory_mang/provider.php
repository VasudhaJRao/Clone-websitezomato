<?php
// Database connection settings
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "inventory";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL query to fetch provider details
$sql = "SELECT provider_id,name,address FROM provider";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PROVIDER DETAILS</title>
    <style>
        body {
            font-family: Courier new,cursive;
            margin: 20px;
            background: url('prr.jpg') no-repeat center center fixed;
            background-size: cover;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
            background-color: whitesmoke;
            font-size: 1em;
        }
        h1{
            font-size: 2.5em;
            color: black;
            font-weight: bold;
            text-decoration-line: underline;
        }
        table, th, td {
            border: 1px solid lavender;
        }
        th, td {
            padding: 12px;
            text-align: left;
        }
        th {
            background-color: lavender;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <h1>PROVIDER DETAILS</h1>
    <table>
        <thead>
            <tr>
                <th>Provider ID</th>
                <th>Provider Name</th>
                <th>address</th>
                
            </tr>
        </thead>
        <tbody>
            <?php
            if ($result->num_rows > 0) {
                // Output data of each row
                while($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td>{$row['provider_id']}</td>
                            <td>{$row['name']}</td>
                            <td>{$row['address']}</td>
                
                          </tr>";
                }
            } else {
                echo "<tr><td colspan='4'>No providers found</td></tr>";
            }
            ?>
        </tbody>
    </table>
</body>
</html>

<?php
$conn->close();
?>
