<?php
include 'connect_db.php';

// Get the time period from the request
$period = isset($_GET['period']) ? intval($_GET['period']) : 7;

// Calculate the start date based on the time period
$startDate = date('Y-m-d', strtotime("-$period days"));

// Fetch inventory data based on the time period
$sql = "SELECT product_name,Price, SUM(quantity_sold) as quantity_sold, quantity_available,quantity_remaining, max_stock,sales_date
        FROM inventory_mang 
        WHERE sales_date >= ?
        GROUP BY product_name, quantity_remaining, max_stock";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $startDate);
$stmt->execute();
$result = $stmt->get_result();

// Check if there are results
$data = array();
while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}

// Close the connection
$conn->close();

// Return the data as JSON
header('Content-Type: application/json');
echo json_encode($data);
?>





